﻿namespace Sitecore.Sharedsource.Pipelines.RenderWord.ProcessWordElement
{
  public abstract class ProcessWordElementProcessor
  {
    public abstract void Process(ProcessWordElementArgs args);
  }
}