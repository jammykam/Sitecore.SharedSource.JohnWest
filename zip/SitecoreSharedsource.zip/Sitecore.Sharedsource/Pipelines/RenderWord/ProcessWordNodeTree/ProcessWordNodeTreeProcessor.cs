﻿namespace Sitecore.Sharedsource.Pipelines.RenderWord.ProcessWordNodeTree
{
  public abstract class ProcessWordNodeTreeProcessor
  {
    public abstract void Process(ProcessWordNodeTreeArgs args);
  }
}