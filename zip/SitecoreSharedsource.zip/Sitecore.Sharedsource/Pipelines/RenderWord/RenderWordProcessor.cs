﻿namespace Sitecore.Sharedsource.Pipelines.RenderWord
{
  public abstract class RenderWordProcessor
  {
    public abstract void Process(RenderWordArgs args);
  }
}